
Main.java executes the primary functions of the project

Configurable constants are:
	size of the teams (team_size)
	number of teams (team_count)
these values are declared in Main.java 

Output is routed through the console and displays primary actions as they happen with timestamps